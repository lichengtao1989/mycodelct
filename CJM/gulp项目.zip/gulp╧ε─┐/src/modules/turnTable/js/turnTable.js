(function () {
  var awardInfo; //中的奖项信息
  var awardNum = 9; //奖项数量
  var delay = 250; //初始转圈的时间间隔
  var currentItem = 1; //当前选中的奖项
  var rollCount = 6 * awardNum; //转圈次数

  //入口函数
  function main() {
    statsInit(); //统计初始化
    bindEvent(); //绑定事件
  }

  main();

  //统计初始化
  function statsInit() {
    cjm.stats.init({
      statsApiUrl: cjm.config.statsUrl,
      corpId: cjm.config.corpId
    });
  }

  //绑定事件
  function bindEvent() {
    $('.award-start').one('click', startLottery);
  }

  /**
   * 获取中奖信息
   * @param callback 回调函数
   */
  function getAward(callback) {
    //真实情况应该ajax获取
    var error = null;
    callback(error, {
      WinRecordID:'1',
      AwardLevel: 2
    });
  };

  //开始抽奖
  function startLottery() {
    getAward(function (error,r) {
      if(error){
        cjm.alert(error);
        return;
      }
      if (!r.WinRecordID) {
        r.AwardLevel = 9;
      }
      rollCount += parseInt(r.AwardLevel);
      awardInfo = r;
      roll();
    });
  };

  //转动大转盘
  function roll() {
    $(".award-item").removeClass("award-active");
    $(".award-" + currentItem).addClass("award-active");
    //切换到下一个奖项
    currentItem++;
    if (currentItem > awardNum) {
      currentItem = 1;
    }
    //增加前几次的速度，并在中间部分保持匀速
    if (rollCount >= 15 && delay > 70) {
      delay -= 20;
    }
    //放慢最后几次的速度
    else if (rollCount < 13) {
      delay += 40;
    }

    rollCount--;
    if (rollCount > 0) {
      setTimeout(roll, delay);
    }
    else {
      setTimeout(function () {
        cjm.alert('自定义之后流程');
      }, 800);
    }
  }
})();