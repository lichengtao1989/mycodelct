var weixinGetedTicket = false;
var weixinInitiError = "";

$(document).ready(function () {
  var ua = navigator.userAgent.toLowerCase();
  if (ua.match(/MicroMessenger/i) == "micromessenger") {
    var codestring = "";
    var access_tokenstring = "";
    var oldTimeStamp; //保存timestamp，提交用
    var oldNonceStr; //保存nonceStr,提交用
    getTicket();
  }
});
function getappid() {
  return 'wx7abe9539c6c71a7f';
}
function getQueryString(name) {
  var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
  var r = window.location.search.substr(1).match(reg);
  if (r != null) return unescape(r[2]);
  return null;
}
function getTimeStamp() {
  var timestamp = new Date().getTime();
  var timestampstring = timestamp.toString().substring(0, 10); //一定要转换字符串
  oldTimeStamp = timestampstring;
  return timestampstring;
}

//得到随机字符串
function getNonceStr() {
  var $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var maxPos = $chars.length;
  var noceStr = "";
  for (i = 0; i < 32; i++) {
    noceStr += $chars.charAt(Math.floor(Math.random() * maxPos));
  }

  oldNonceStr = noceStr;
  return noceStr;
}

//拼接url传参字符串
function perapara(objvalues, isencode) {
  var parastring = "";
  for (var key in objvalues) {
    isencode = isencode || false;
    if (isencode) {
      parastring += (key + "=" + encodeURIComponent(objvalues[key]) + "&");
    }
    else {
      parastring += (key + "=" + objvalues[key] + "&");
    }
  }
  parastring = parastring.substr(0, parastring.length - 1);
  return parastring;
}
var starTime = 0;
//得到用户accesstoken
function getTicket() {
  var endingTime = new Date().getTime();
  var tTime = endingTime - starTime;
  starTime = endingTime;

  if (tTime > 500) {
    $.ajax({
      url: "http://wap.cjm.so/Common/DataService.ashx?function=GetWeixinTicket&Key=27",
      cache: false,
      async: false,
      type: "get",
      dataType: "jsonp",
      success: function (data, textStatus) {
        if (data && data.success) {
          access_tokenstring = data.result.Ticket;
          weixinGetedTicket = true;

          if (access_tokenstring == "") {
            return;
          }

          function getSign(beforesingstring) {
            var sign = CryptoJS.SHA1(beforesingstring).toString();
            return sign;
          }

          var signparasobj = {
            "jsapi_ticket": "",
            "noncestr": "",
            "timestamp": "",
            "url": ""
          };

          var signparas = $.extend(signparasobj, {
            "jsapi_ticket": access_tokenstring,
            "noncestr": getNonceStr(),
            "timestamp": getTimeStamp(),
            "url": window.location.href.split('#')[0]
          });
          var signstring = getSign(perapara(signparas));
          wx.config({
            debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
            appId: getappid(), // 必填，公众号的唯一标识
            timestamp: oldTimeStamp, // 必填，生成签名的时间戳
            nonceStr: oldNonceStr, // 必填，生成签名的随机串
            signature: signstring, // 必填，签名，见附录1
            jsApiList: ['scanQRCode'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
          });

          wx.ready(function () {
            $("#scanning").click(function () {
              if (weixinGetedTicket) {
                try {
                  wx.scanQRCode({
                    needResult: 1, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
                    scanType: ["qrCode", "barCode"], // 可以指定扫二维码还是一维码，默认二者都有
                    success: function (res) {
                      var url = res.resultStr;
                      var code = url.match(/\d{14,22}/ig);
                      if(code.length === 17){
                        $('#integralCode_right').show();
                      }else {
                        $('#integralCode_right').hide();
                      }
                      $('#integralCode,#integralCode_left').val(code);
                      $('#integralCode_right').val('');
                    },
                    cancel: function (res) {
                    },
                    fail: function (res) {
                      alert("扫码失败")
                    }
                  });
                } catch (e) {
                  alert("无法使用扫码功能");
                }
              }
              else {
                alert("无法使用扫码功能:" + weixinInitiError);
              }
            });

          });

          wx.error(function (res) {
            // config信息验证失败会执行error函数，如签名过期导致验证失败，具体错误信息可以打开config的debug模式查看，也可以在返回的res参数中查看，对于SPA可以在这里更新签名。
          });
        }
        else {
          weixinInitiError = "获取Ticket失败:" + data.message;
        }
      }
    });
  }
}

