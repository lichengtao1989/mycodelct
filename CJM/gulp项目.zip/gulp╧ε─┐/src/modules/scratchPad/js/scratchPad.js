(function () {
  var code; //码
  var award; //奖项信息

  //入口函数
  function main() {
    code = cjm.url.getParam('code');
    if (!code) {
      cjm.alert('缺少code参数');
      return;
    }
    statsInit(); //统计初始化
    //获取奖项
    addLotteryRecord(function (error, _award) {
      if (error) {
        cjm.alert(error);
        return;
      }
      award = _award;
      if (_award.LotteryAwardsSettingID) {
        $('.scratchPad-content-awardName').html('运气不错哦，刮到' + _award.AwardName);
      } else {
        $('.scratchPad-content-awardName').html('谢谢惠顾');
      }
      $('.scratchPad-content').css('visibility', 'visible');
      scratchPadInit(); //刮刮卡初始化
    });
  }

  main();

  //统计初始化
  function statsInit() {
    cjm.stats.init({
      statsApiUrl: cjm.config.statsUrl,
      corpId: cjm.config.corpId
    });
  }

  //刮刮卡初始化
  function scratchPadInit() {
    var width = $('#scratchPadMask').width();
    var size = width / 12;
    $('#scratchPadMask').wScratchPad({
      bg: 'transparent',
      fg: '#D6D5D6',
      size: size,
      scratchUp: function (e, percent) {
        if (percent > 20) {
          this.clear();
          this.enabled = false;
          if (award.LotteryAwardsSettingID) {
            cjm.alert('恭喜您获得' + award.AwardName);
          } else {
            cjm.alert('很可惜，没中奖哦~');
          }

        }
      }
    });
  }

  //添加抽奖纪录
  function addLotteryRecord(callback) {
    //测试数据
    callback(null,{
      LotteryAwardsSettingID:'XXX',
      AwardName:'一等奖'
    });
    // $.ajax({
    //   type: 'post',
    //   url: cjm.config.addLotteryRecordUrl,
    //   dataType: 'json',
    //   data: {
    //     Code: code
    //   },
    //   success: function (data) {
    //     if (data && data.success) {
    //       callback(null, data.result);
    //     } else if (data && data.message) {
    //       callback(data.message);
    //     } else {
    //       callback('服务器异常，请稍后再试');
    //     }
    //   },
    //   error: function () {
    //     callback('网络异常');
    //   }
    // });
  }
})();