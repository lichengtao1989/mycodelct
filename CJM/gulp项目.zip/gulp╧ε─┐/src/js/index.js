(function () {
    var codeType = 1; //1：普通码 2：明暗码
    //入口函数
    function main() {
      statsInit(); //统计初始化
      navInit(); //导航初始化
      codeInit(); //码相关的文本框初始化和赋值
      bindEvent(); //绑定事件
      cookieValueInit(); //cookie值初始化
    }

    main();
    //corpID 补0
    function initCorpID(corpID) {
      while (String(corpID).length < 5) {
        corpID = '0' + corpID;
      }
      return corpID;
    }

    //统计初始化
    function statsInit() {
      cjm.stats.init({
        statsApiUrl: cjm.config.statsUrl,
        corpId: cjm.config.corpId
      });
    }

    //导航初始化
    function navInit() {
      //根据url参数选中对应的导航
      var navTag = cjm.url.getParam('type');
      var code = cjm.url.getParam('code');
      if (navTag) {
        cjm.nav.switchTo($(String.format('[data-nav-tag={0}]', navTag)));
      }

      //移动商城
      $('#navMall').attr('href', cjm.config.mallUrl);
      //刮刮卡
      $('#navScratchPad').attr('href', 'modules/scratchPad/scratchPad.html?code=' + code);
      //大转盘
      $('#navTurnTable').attr('href', 'modules/turnTable/turnTable.html?code=' + code);
    }

    //码相关的文本框初始化和赋值
    function codeInit() {
      //根据code初始化不同的输入框
      var code = cjm.url.getParam('code');
      //获取地理位置
      $('#uuid').val(cjm.url.getParam('uuid'));
      if (cjm.validator.isMingAnMa(code)) {
        codeType = 2;
        cjm.input.initMingAnMaInput('#antiCode');
        cjm.input.initMingAnMaInput('#integralCode');
      }

      //绑定文本框输入事件
      if (codeType === 1) {
        $('#antiCode,#integralCode,#traceCode').on('input', function () {
          $('#antiCode,#integralCode,#traceCode').val($(this).val());
        })
      } else {
        $('#antiCode_right,#integralCode_right').on('input', function () {
          $('#antiCode_right,#integralCode_right').val($(this).val());
        })
      }

      //绑定码到文本框
      codeBind();
    }

    //初始化cookie值
    function cookieValueInit() {
      var userMobile = localStorage.getItem('userMobile');
      var guideMobile = localStorage.getItem('guideMobile');
      if (userMobile) {
        $('#mobile').val(userMobile);
      }

      if (guideMobile) {
        $('#guideMobile').val(guideMobile)
      }
    }

    //把码绑定到文本框
    function codeBind() {
      var code = cjm.url.getParam('code');
      var logisticsCode = '';
      if (!code) {
        return;
      }
      //自动填入code
      if (codeType === 1) {
        $('#antiCode').val(code);
        if (code.length != 16 && code.length != 18) {
          $('#integralCode').val(code);
        }
        //根据防伪码得到物流码（先从seesionStorage取，取不到再从接口获取），如果没有物流查询功能，建议删除以下代码
        logisticsCode = sessionStorage.getItem('logisticsCode');
        if (logisticsCode === null) {
          var callback = function (error, data) {
            if (!error && data.success) {
              logisticsCode = data.result.LogisticsCode || '';
              $('#logisticsCode').val(logisticsCode);
              sessionStorage.setItem('logisticsCode', logisticsCode);
            }
          };
          cjm.api.getLogisticsCode(cjm.config.getLogisticsCodeUrl, {
            code: code,
            corpId: cjm.config.corpId
          }, callback);
        } else {
          $('#logisticsCode').val(logisticsCode);
        }
      } else {
        $('#antiCode_left').val(code);
        $('#integralCode_left').val(code);
        $('#logisticsCode').val(code);
      }
      $('#traceCode').val(code);
    }

    //绑定事件
    function bindEvent() {
      //验证码图片点击事件
      $('body').on('click', '#verificationCodeImg', function () {
        $('#verificationCodeImg').attr('src', cjm.config.verificationCodeUrl);
      });

      //页面显示事件
      $(window).on('pageshow', function () {
        $(function () {
          codeBind();
        });
      });

      //弹窗点击事件
      $('.close-btn,.success-btn').on('click', function () {
        $('.alert').hide();
      });
      $('.banner').click(function () {
        window.location.href = 'http://cjm.app315.net/Module/WeixinManage/MicroPageShow.aspx?PageID=eefbf9a9-b4c8-4b5c-8a19-9257528bc58e';
      });
      $('#scanning').click(function () {
        var ua = window.navigator.userAgent.toLowerCase();
        if (ua.match(/MicroMessenger/i) != 'micromessenger') {
          cjm.alert('请用微信扫一扫！');
          return false;
        }
      });

      //点击展开更多
      $('.show-more').click(function () {
        $('#guideMobileBlock').slideToggle(function () {
          var text = $('.show-more').html();
          if (text === '点击展开更多') {
            $('.show-more').html('点击收起');
          } else {
            $('.show-more').html('点击展开更多');
          }
        })
      });
      antifakeQuery(); //防伪查询
      traceQuery(); //溯源查询
      integralRecharge(); //积分充值
      integralQuery(); //积分查询
      logisticsQuery(); //物流查询
      wx(); //微信授权
    }

    //防伪查询
    function antifakeQuery() {
      //防伪查询是否需要验证码
      var needVerificationCode = false;
      //开始查询
      var beginRequest = function () {
        $('#antiFakeQuery').text('查询中...');
      };
      //结束查询
      var endRequest = function () {
        $('#antiFakeQuery').text('查 询');
      };
      //防伪查询的回调函数
      var callback = function (error, data) {
        if (error) {
          cjm.alert(error.message);
          endRequest();
          return;
        }
        if (!data.success || !data.result.ResultID) {
          cjm.alert(data.message);
          if (data.result.validate_code_error == 1) {
            $('#verificationCodeImg').attr('src', cjm.config.verificationCodeUrl);
            $('#verificationCodeItem').show();
            needVerificationCode = true;
          }
          endRequest();
          return;
        }
        location.href = cjm.config.getAntifakeQueryResultUrl(data.result.ResultID);
      };

      $('#antiFakeQuery').on('click', function () {
        var code = codeType === 1 ? $('#antiCode').val() : $('#antiCode_left').val() + $('#antiCode_right').val();
        var verificationCode = $('#verificationCode').val();

        beginRequest();
        cjm.api.antifakeQuery(cjm.config.antifakeQueryUrl, {
          code: code,
          needVerificationCode: needVerificationCode,
          verificationCode: verificationCode
        }, callback);
      });

      $(window).on('pageshow', function () {
        $(function () {
          endRequest();
        });
      });
    }


    //积分充值
    function integralRecharge() {
      //开始充值
      var beginRequest = function () {
        $('#integralRecharge').text('充值中...');
      };
      //结束充值
      var endRequest = function () {
        $('#integralRecharge').text('充 值');
      };
      //注册成功、积分失败的弹出框模板
      var registerSuccessHTML =
        '<p class="register-success-title">您已注册为<span>{0}</span>会员</p>' +
        '<p class="register-success-account">帐号：{1}</p>' +
        '<p class="register-success-account">密码：{2}</p>' +
        '<p class="register-success-warn">积分失败：{3}</p>';
      var echangeSuccessHTML;
      var code;
      var mobile;
      var guide;
      var callback = function (error, data) {
        if (error) {
          cjm.alert(error.message);
          endRequest();
          return;
        }

        if (data.success) {
          //充值成功

          if (data.result.CreditResult.Registered === '1') {
            echangeSuccessHTML =
              '<p>首次充值成功【' + data.result.CreditResult.ChangeValue + '】！</p>' +
              '<p>您已注册成我们的会员。</p>' +
              '<p>账号密码已通过短信发送手机，</p>' +
              '<p>请您及时登录会员中心并修改密码。</p>';
            $('.success-words').html(echangeSuccessHTML);
            $('.alert').show();
          } else {
            $('.success-logo').hide();
            $('.alert .content').css('top', 330 / 64 + 'rem');
            echangeSuccessHTML = '<p class="single">充值成功【' + data.result.CreditResult.ChangeValue + '】！总积分：【' + data.result.CreditResult.RemainValue + '】</p>';
            cjm.alert(echangeSuccessHTML);
            }
            // $('.success-words').html(echangeSuccessHTML);
            // $('.alert').show();
            endRequest();
            localStorage.setItem('userMobile', mobile);
            localStorage.setItem('guideMobile', guide);
          } else if (data.result && data.result.CreditResult && data.result.CreditResult.Registered == '1') {
            //充值失败 但注册成功
            var corpName = (data.result.CorpName || '');
            var loginName = (data.result.CreditResult.LoginName || '');
            var password = (data.result.CreditResult.Password || '');
            cjm.alert(String.format(registerSuccessHTML, corpName, loginName, password, data.message));
            endRequest();
          } else {
            //充值失败
            cjm.alert('积分失败：' + data.message);
            endRequest();
          }
        };

        $('#integralRecharge').on('click', function () {
          code = codeType === 1 ? $('#integralCode').val().trim() : $('#integralCode_left').val().trim() + $('#integralCode_right').val().trim();
          mobile = $('#mobile').val().trim();
          guide = $('#guideMobile').val().trim();
          beginRequest();
          var corpID = initCorpID(cjm.config.corpId);
          cjm.api.integrateRecharge(cjm.config.integralRechargeUrl, {
            code: code,
            mobile: mobile,
            guide: guide ? guide + '@' + corpID : '',
            orgCode: '',
            referrer: ''
          }, callback);
        });

        $(window).on('pageshow', function () {
          $(function () {
            endRequest();
          });
        });
      }

      //溯源查询
      function traceQuery() {
        //开始查询
        var beginRequest = function () {
          $('#traceQuery').text('查询中...');
        };
        //结束查询
        var endRequest = function () {
          $('#traceQuery').text('查 询');
        };
        var code;
        var callback = function (error, data) {
          if (error) {
            cjm.alert(error.message);
            endRequest();
            return;
          }
          if (!data.success) {
            cjm.alert(data.message);
            endRequest();
            return;
          }
          location.href = cjm.config.getTraceQueryResultUrl(code, $('#uuid').val());
        };

        $('#traceQuery').on('click', function () {
          code = $('#traceCode').val();
          beginRequest();
          cjm.api.traceQuery(cjm.config.traceQueryUrl, {
            code: code,
            corpId: cjm.config.corpId
          }, callback);
        });

        $(window).on('pageshow', function () {
          $(function () {
            endRequest();
          });
        });
      }

      //积分查询
      function integralQuery() {
        //开始查询
        var beginRequest = function () {
          $('#integralQuery').text('查询中...');
        };
        //结束查询
        var endRequest = function () {
          $('#integralQuery').text('查 询');
        };
        var loginName;
        var password;
        var callback = function (error, data) {
          if (error) {
            cjm.alert(error.message);
            endRequest();
            return;
          }
          if (!data.success) {
            cjm.alert(data.message);
            endRequest();
            return;
          }
          location.href = cjm.config.getIntegralQueryResultUrl(cjm.config.corpId, loginName);
        };

        $('#integralQuery').on('click', function () {
          loginName = trim($('#customerLoginName').val());
          password = trim($('#customerPassword').val());
          beginRequest();
          cjm.api.customerLogin(cjm.config.customerLoginUrl, {
            loginName: loginName,
            password: password
          }, callback);
        });

        $(window).on('pageshow', function () {
          $(function () {
            endRequest();
          });
        });
      }

      //物流查询
      function logisticsQuery() {
        //开始查询
        var beginRequest = function () {
          $('#logisticsQuery').text('查询中...');
        };
        //结束查询
        var endRequest = function () {
          $('#logisticsQuery').text('查 询');
        };
        var code;
        var loginName;
        var password;
        var callback = function (error, data) {
          if (error) {
            cjm.alert(error.message);
            endRequest();
            return;
          }
          if (!data.success) {
            cjm.alert(data.message);
            endRequest();
            return;
          }
          location.href = cjm.config.getLogisticsQueryResultUrl(code);
        };

        $('#logisticsQuery').on('click', function () {
          code = $('#logisticsCode').val().trim();
          loginName = $('#loginName').val().trim();
          password = $('#password').val().trim();
          beginRequest();
          cjm.api.logisticsQuery(cjm.config.logisticsQueryUrl, {
            code: code,
            loginName: loginName,
            password: password,
            corpId: cjm.config.corpId
          }, callback);
        });

        $(window).on('pageshow', function () {
          $(function () {
            endRequest();
          });
        });
      }

      //微信授权
      function wx() {
        $('#navWx').on('click', function () {
          location.href = cjm.config.getWxOpenIdUrl(cjm.config.currentHost + '/modules/wechat/wechat.html');
        });
      }
    })();