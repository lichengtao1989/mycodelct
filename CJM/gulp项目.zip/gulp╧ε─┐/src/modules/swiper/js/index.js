(function () {
  new Swiper('.banner', {
    autoplay: 3000,
    autoplayDisableOnInteraction: false,
    speed: 800,
    loop: true,
    pagination: '.swiper-pagination'
  });
})();
