var gulp = require("gulp");
var autoPrefixer = require('autoPrefixer'); //自动生成兼容的css样式
var postCss = require('gulp-postCss');
var less = require("gulp-less");
var minifyCss = require("gulp-minify-css");//压缩css
var rename = require("gulp-rename");//重命名
var uglify = require("gulp-uglify");//压缩js
var runSequence = require('run-sequence'); //按顺序执行任务
var clean = require('gulp-clean'); //清理文件
var concat = require("gulp-concat");//合并文件
var browserSync = require('browser-sync').create(); //浏览器热重载
var proxy = require('http-proxy-middleware'); //http代理
var base64 = require('gulp-base64'); //css中图片base64编码
var img64 = require('gulp-img64-2'); //html中图片base64编码
var through = require('through2');
var htmlminify = require("gulp-html-minify");
var inlinesource = require('gulp-inline-source'); //将html中带有inline属性的资源内联
var gulpif = require('gulp-if');

// 设置代理
var middleware = [
  proxy('/Common', {
    target: 'http://www.kf315.net/newwap',
    changeOrigin: true
  }),
  proxy('/Operator', {
    target: 'http://www.kf315.net/newwap',
    changeOrigin: true
  }),
  proxy('/newwap', {
    target: 'http://www.kf315.net',
    changeOrigin: true
  }),
  proxy('/NewWap', {
    target: 'http://www.kf315.net',
    changeOrigin: true
  })
];

var build = {
  'root': 'build',
  'js': 'build/js',
  'css': 'build/css',
  'image': 'build/images',
  'lib': 'build/lib'
};
var src = {
  'root': 'src',
  'js': 'src/js',
  'css': 'src/css',
  'image': 'src/images',
  'lib': 'src/lib'
};

/**
 * 清除文件
 */
gulp.task('build.clean', function () {
  return gulp.src('build')
    .pipe(clean({force: true}));
});

/**
 * 编译压缩css
 */
gulp.task("build.css", function () {
  gulp.src([src.css + '/**/*.less'])
    .pipe(less())
    .pipe(postCss([autoPrefixer()]))
    .pipe(base64({
      maxImageSize: 10 * 1024  //10KB以内的小图片用base64图像
    }))
    .pipe(minifyCss())
    .pipe(gulp.dest(build.css));
});

/**
 * 编译压缩js
 */
gulp.task("build.js", function () {
  gulp.src([src.js + '/**/*.js'])
    .pipe(gulpif('!config.js', uglify()))
    .pipe(gulp.dest(build.js));
});

/**
 * 移动lib文件夹
 */
gulp.task("build.lib", function () {
  gulp.src([src.lib + '/**/*.*'])
    .pipe(gulp.dest(build.lib));
});

/**
 * 筛选大于10KB的图片
 */
var filterFile = through.obj(function (file, encoding, callback) {
  if (file.contents.length > 1024 * 10) {
    callback(null, file);
  } else {
    callback();
  }
});

/**
 * 编译images
 */
gulp.task('build.image', function () {
  gulp.src([src.image + '/**/*.*'])
    // .pipe(filterFile)
    .pipe(gulp.dest(build.image));
});

/**
 * 编译html
 */
gulp.task('build.html', function () {
  gulp.src(['src/*.html'])
    .pipe(inlinesource())
    .pipe(htmlminify())
    .pipe(img64({
      maxWeightResource: 10 * 1024
    }))
    .pipe(gulp.dest('build'));
});

/**
 * 编译压缩css
 */
gulp.task("dev.css", function () {
  gulp.src(src.css + '/*.less')
    .pipe(less())
    .pipe(postCss([autoPrefixer()]))
    .pipe(base64({
      maxImageSize: 10 * 1024  //10KB以内的小图片用base64图像
    }))
    .pipe(gulp.dest(src.css));

  gulp.src(src.root + '/modules/*/css/*.less', {base:'.'})
    .pipe(less())
    .pipe(postCss([autoPrefixer()]))
    .pipe(base64({
      maxImageSize: 10 * 1024  //10KB以内的小图片用base64图像
    }))
    .pipe(gulp.dest(''));
});

/**
 * 监听文件变化
 */
gulp.task("dev.watch", function () {
  //监听less
  gulp.watch([src.css + '/*.less', src.root + '/modules/*/css/*.less'], ["dev.css"]);

  browserSync.init({
    server: {
      baseDir: './src'
    },
    files: [
      src.css + '/*.css',
      src.js + '/*.js',
      src.root + '/modules/*/css/*.css',
      src.root + '/modules/*/js/*.js',
      src.root + '/modules/*/*.html',
      'src/*.html'
    ],
    middleware: middleware
  });
});

/**
 * 生产
 */
gulp.task('build', function (done) {
  runSequence(
    ['build.clean'],
    ['build.image', 'build.css', 'build.js', 'build.lib', 'build.html'],
    done);
});

/**
 * 开发
 */
gulp.task('dev', function (done) {
  runSequence(
    ["dev.css", "dev.watch"],
    done);
});

gulp.task("default", ['dev']);